public class PPMImageDriver {
	public static void main(String[] args) {
		PPMImageDriver ob = new PPMImageDriver();
		double m1 = ob.checkFlattenColour();
		System.out.println();
		double m2 = ob.checkNegateColour();
		System.out.println();
		double m3 = ob.checkGreyScale();
		System.out.println();
		double m4 = ob.checkTile();
		System.out.println();
		double m5 = ob.checkScale();

		double sum = m1 + m2 + m3 + m4 + m5;
		System.out.println();
		System.out.println();
		System.out.println("TOTAL OBTAINED SCORE: " + sum);
		System.out.println();

	}

	private double checkFlattenColour() {

		double val = 0.0d;

		System.out.println("Check flatten colour");
		System.out.println("Test 1: Flatten Red");

		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.flattenColor("red");
			img1.save("flattenRed.ppm");
			PPMImage img2 = new PPMImage("flattenRed1.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 1;
			} else {
				System.out.println("Failed. Check flattenRed.ppm visually.");
			}

		} catch (Exception e) {
			System.out
					.println("Exception thrown. Check flattenRed.ppm visually");
		}

		System.out.println("Test 2: Flatten Green");
		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.flattenColor("green");
			img1.save("flattenGreen.ppm");
			PPMImage img2 = new PPMImage("flattenGreen1.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 1;
			} else {
				System.out.println("Failed. Check flattenGreen.ppm visually.");
			}

		} catch (Exception e) {
			System.out
					.println("Exception thrown. Check flattenGreen.ppm visually");
		}

		System.out.println("Test 3: Flatten Blue");
		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.flattenColor("blue");
			img1.save("flattenBlue.ppm");
			PPMImage img2 = new PPMImage("flattenBlue1.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 1;
			} else {
				System.out.println("Failed. Check flattenBlue.ppm visually.");
			}

		} catch (Exception e) {
			System.out
					.println("Exception thrown. Check flattenBlue.ppm visually");
		}

		System.out
				.println("Test 4: Flatten ASDF, not a valid input, image should stay the same.");
		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.flattenColor("asdf");
			img1.save("flattenFail.ppm");
			PPMImage img2 = new PPMImage("image2.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 1;
			} else {
				System.out.println("Failed. Check flattenFail.ppm visually.");
			}

		} catch (Exception e) {
			val += 1;
			System.out.println("Passed");
		}

		return val;
	}

	private double checkNegateColour() {

		double val = 0.0d;

		System.out.println("Check negate colour");
		System.out.println("Test 1: Negate Red");

		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.negateColor("red");
			img1.save("negateRed.ppm");
			PPMImage img2 = new PPMImage("negateRed1.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 1;
			} else {
				System.out.println("Failed. Check negateRed.ppm visually.");
			}

		} catch (Exception e) {
			System.out
					.println("Exception thrown. Check negateRed.ppm visually");
		}

		System.out.println("Test 2: Negate Green");
		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.negateColor("green");
			img1.save("negateGreen.ppm");
			PPMImage img2 = new PPMImage("negateGreen1.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 1;
			} else {
				System.out.println("Failed. Check negateGreen.ppm visually.");
			}

		} catch (Exception e) {
			System.out
					.println("Exception thrown. Check negateGreen.ppm visually");
		}

		System.out.println("Test 3: Negate Blue");
		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.negateColor("blue");
			img1.save("negateBlue.ppm");
			PPMImage img2 = new PPMImage("negateBlue1.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 1;
			} else {
				System.out.println("Failed. Check negateBlue.ppm visually.");
			}

		} catch (Exception e) {
			System.out
					.println("Exception thrown. Check negateBlue.ppm visually");
		}

		System.out
				.println("Test 4: negate ASDF, not a valid input, image should stay the same.");
		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.negateColor("asdf");
			img1.save("negateFail.ppm");
			PPMImage img2 = new PPMImage("image2.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 1;
			} else {
				System.out.println("Failed. Check negateFail.ppm visually.");
			}

		} catch (Exception e) {
			val += 1;
			System.out.println("Passed");
		}

		return val;
	}

	private double checkGreyScale() {

		double val = 0.0d;

		System.out.println("Grey Scale:");
		System.out.println("Test 1:");

		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.greyScale();
			img1.save("greyScale.ppm");
			PPMImage img2 = new PPMImage("greyScale1.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 4;
			} else {
				System.out.println("Failed. Check greyScale.ppm visually.");
			}

		} catch (Exception e) {
			System.out
					.println("Exception thrown. Check greyScale.ppm visually");
		}

		return val;
	}

	private double checkTile() {

		double val = 0.0d;

		System.out.println("Check tile");
		System.out.println("Test 1: (2,2)");

		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.tile(2, 2);
			img1.save("titl_1.ppm");
			PPMImage img2 = new PPMImage("titl1.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 2;
			} else {
				System.out.println("Failed. Check titl_1.ppm visually.");
			}

		} catch (Exception e) {
			System.out.println("Exception thrown. Check titl_1.ppm visually");
		}

		System.out.println("Test 2: (1,2)");
		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.tile(1, 2);
			img1.save("titl_2.ppm");
			PPMImage img2 = new PPMImage("titl2.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 2;
			} else {
				System.out.println("Failed. Check titl_2.ppm visually.");
			}

		} catch (Exception e) {
			System.out.println("Exception thrown. Check titl_2.ppm visually");
		}

		System.out.println("Test 3: (3,2)");
		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.tile(3, 2);
			img1.save("titl_3.ppm");
			PPMImage img2 = new PPMImage("titl3.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 2;
			} else {
				System.out.println("Failed. Check titl_3.ppm visually.");
			}

		} catch (Exception e) {
			System.out.println("Exception thrown. titl_3.ppm visually");
		}
		return val;
	}

	private double checkScale() {

		double val = 0.0d;

		System.out.println("Check scale");
		System.out.println("Test 1: (0.8,0.5)");

		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.scale(0.8, 0.5);
			img1.save("scale_1.ppm");
			PPMImage img2 = new PPMImage("scale1.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 3;
			} else {
				System.out.println("Failed. Check scale_1.ppm visually.");
			}

		} catch (Exception e) {
			System.out.println("Exception thrown. Check scale_1.ppm visually");
		}

		System.out.println("Test 2: (1.5,1.8)");
		try {
			PPMImage img1 = new PPMImage("image1.ppm");
			img1.scale(1.5, 1.8);
			img1.save("scale_2.ppm");
			PPMImage img2 = new PPMImage("scale2.ppm");

			if (check(img1, img2)) {
				System.out.println("Passed");
				val += 3;
			} else {
				System.out.println("Failed. Check scale_2.ppm visually.");
			}

		} catch (Exception e) {
			System.out.println("Exception thrown. Check scale_2.ppm visually");
		}

		return val;
	}

	private boolean check(PPMImage img1, PPMImage img2) {
		Pixel[][] p1 = img1.getPixels();
		Pixel[][] p2 = img2.getPixels();

		if (p1.length != p2.length) {
			return false;
		}

		for (int i = 0; i < p1.length; i++) {
			if (p1[i].length != p2[i].length) {
				return false;
			}

			for (int j = 0; j < p1[i].length; j++) {
				if (p1[i][j].getRed() != p2[i][j].getRed()
						|| p1[i][j].getBlue() != p2[i][j].getBlue()
						|| p1[i][j].getGreen() != p2[i][j].getGreen()) {
					return false;
				}
			}
		}

		return true;
	}
}
